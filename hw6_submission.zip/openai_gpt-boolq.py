import os
import argparse
import random
import torch
from datasets import load_dataset
from openai import OpenAI

def build_few_shot_prompt(demonstrations, eval_passage, eval_question):
    instruction = "Answer the question using the passage. Reply only Yes or No.\n\n"
    demo_text = ""
    for demo in demonstrations:
        label_str = "Yes" if demo["answer"] else "No"
        demo_text += f"Passage: {demo['passage']}\nQuestion: {demo['question']}\nAnswer: {label_str}\n\n"
    
    query_text = f"Passage: {eval_passage}\nQuestion: {eval_question}\nAnswer:"
    return instruction + demo_text + query_text

def get_completion(client, prompt, model_name):
    # Support both completion and chat-based models
    try:
        if "instruct" in model_name or "davinci" in model_name:
            response = client.completions.create(
                model=model_name,
                prompt=prompt,
                max_tokens=5,
                temperature=0.0,
                stop=["\n"]
            )
            return response.choices[0].text.strip()
        else:
            response = client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant that answers questions based on passages with only Yes or No."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=5,
                temperature=0.0
            )
            return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"API Error: {e}")
        return "ERROR"

def parse_answer(raw_answer):
    raw_lower = raw_answer.strip().lower()
    if raw_lower.startswith("yes"):
        return True
    elif raw_lower.startswith("no"):
        return False
    return None

def main():
    parser = argparse.ArgumentParser(description="Few-shot prompting for BoolQ using OpenAI GPT")
    parser.add_argument("--model", type=str, default="gpt-5.6-terra",
                        help="Model to use (e.g. gpt-5.6-terra, modern replacement for retired gpt-3.5-turbo-instruct)")
    parser.add_argument("--num_eval", type=int, default=30, help="Number of examples to evaluate")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    print("Loading BoolQ dataset...")
    dataset = load_dataset("boolq")
    shuffled_train = dataset["train"].shuffle(seed=args.seed)

    # 8k pool for train/demos, remaining for test
    train_pool = shuffled_train[:8000]
    test_pool = shuffled_train[8000:]

    # Find 4 Yes and 4 No demonstrations
    yes_demos = []
    no_demos = []
    for i in range(len(train_pool["passage"])):
        item = {
            "passage": train_pool["passage"][i],
            "question": train_pool["question"][i],
            "answer": train_pool["answer"][i]
        }
        if item["answer"] is True and len(yes_demos) < 4:
            yes_demos.append(item)
        elif item["answer"] is False and len(no_demos) < 4:
            no_demos.append(item)
        if len(yes_demos) == 4 and len(no_demos) == 4:
            break

    # Interleave demonstrations: Yes, No, Yes, No, Yes, No, Yes, No
    demos = []
    for y, n in zip(yes_demos, no_demos):
        demos.append(y)
        demos.append(n)

    print(f"Prepared {len(demos)} interleaved few-shot demonstrations (4 Yes, 4 No).")

    # Sample 30 eval instances from test_pool
    eval_indices = random.sample(range(len(test_pool["passage"])), args.num_eval)
    eval_samples = [{
        "passage": test_pool["passage"][idx],
        "question": test_pool["question"][idx],
        "answer": test_pool["answer"][idx]
    } for idx in eval_indices]

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Note: OPENAI_API_KEY environment variable is not set. Please set it to run live API calls.")
        print("Example: export OPENAI_API_KEY='your-key-here'")
        print("A demonstration prompt for inspection:")
        demo_prompt = build_few_shot_prompt(demos, eval_samples[0]["passage"], eval_samples[0]["question"])
        print("-" * 50)
        print(demo_prompt[:500] + "...\n[truncated]\n..." + demo_prompt[-150:])
        print("-" * 50)
        return

    client = OpenAI(api_key=api_key)
    correct = 0
    total = len(eval_samples)

    print(f"Evaluating {total} examples using model '{args.model}'...")
    for idx, sample in enumerate(eval_samples):
        prompt = build_few_shot_prompt(demos, sample["passage"], sample["question"])
        raw_pred = get_completion(client, prompt, args.model)
        parsed_pred = parse_answer(raw_pred)
        is_correct = (parsed_pred == sample["answer"])
        if is_correct:
            correct += 1
        print(f"[{idx+1}/{total}] True: {'Yes' if sample['answer'] else 'No'} | Raw: '{raw_pred}' | Correct: {is_correct}")

    accuracy = correct / total
    print("=" * 40)
    print(f"Final Few-Shot Accuracy on {total} examples: {accuracy:.4f} ({correct}/{total})")
    print("=" * 40)

if __name__ == "__main__":
    main()
